import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { ContentItem } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ContentUploadForm from "@/components/ContentUploadForm";
import ContentTable from "@/components/ContentTable";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import FileUpload from "@/components/FileUpload";
import { Loader2 } from "lucide-react";

const Admin = () => {
  const [, navigate] = useLocation();
  const { isAuthenticated, isLoading, logout } = useAuth();
  const [activeTab, setActiveTab] = useState("upload");
  const [editingContent, setEditingContent] = useState<ContentItem | null>(null);
  const [editFormOpen, setEditFormOpen] = useState(false);
  const [updatedFile, setUpdatedFile] = useState<File | null>(null);
  const { toast } = useToast();
  
  // Check authentication
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      navigate("/login");
    }
  }, [isAuthenticated, isLoading, navigate]);
  
  const updateMutation = useMutation({
    mutationFn: async ({ id, formData }: { id: number; formData: FormData }) => {
      const response = await fetch(`/api/content/${id}`, {
        method: "PATCH",
        body: formData,
        credentials: "include"
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Error updating content");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/content"] });
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      toast({
        title: "Success",
        description: "Content updated successfully",
      });
      setEditFormOpen(false);
      setEditingContent(null);
      setUpdatedFile(null);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Error updating content",
      });
    }
  });
  
  const handleEditContent = (content: ContentItem) => {
    setEditingContent(content);
    setEditFormOpen(true);
  };
  
  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingContent) return;
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData();
    
    // Add form fields to formData
    const data = {
      title: (form.elements.namedItem("title") as HTMLInputElement).value,
      description: (form.elements.namedItem("description") as HTMLTextAreaElement).value,
      tag: (form.elements.namedItem("tag") as HTMLSelectElement).value || undefined,
      ctaLink: (form.elements.namedItem("ctaLink") as HTMLInputElement).value,
      ctaText: (form.elements.namedItem("ctaText") as HTMLInputElement).value,
      status: (form.elements.namedItem("status") as HTMLSelectElement).value,
    };
    
    formData.append("data", JSON.stringify(data));
    
    // Add file if selected
    if (updatedFile) {
      formData.append("image", updatedFile);
    }
    
    updateMutation.mutate({ id: editingContent.id, formData });
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }
  
  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-secondary text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold cursor-pointer">LEAKSFREEDAY Admin</h1>
          </div>
          
          <div className="flex items-center space-x-6">
            <Button 
              variant="link" 
              className="text-white hover:text-gray-300"
              onClick={() => navigate("/")}
            >
              View Site
            </Button>
            <Button 
              variant="default" 
              className="bg-primary text-white hover:bg-primary/90"
              onClick={() => logout()}
            >
              Logout
            </Button>
          </div>
        </div>
      </nav>
      
      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="upload" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="upload">Upload Content</TabsTrigger>
            <TabsTrigger value="manage">Manage Content</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upload">
            <ContentUploadForm />
          </TabsContent>
          
          <TabsContent value="manage">
            <ContentTable onEdit={handleEditContent} />
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Edit Content Dialog */}
      <Dialog open={editFormOpen} onOpenChange={setEditFormOpen}>
        <DialogContent className="max-w-3xl">
          <h2 className="text-2xl font-bold mb-6">Edit Content</h2>
          
          {editingContent && (
            <form onSubmit={handleUpdate} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">Content Title</label>
                  <input 
                    type="text" 
                    id="title" 
                    name="title"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    defaultValue={editingContent.title}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="tag" className="block text-sm font-medium text-gray-700 mb-1">Tag (Optional)</label>
                  <select 
                    id="tag" 
                    name="tag"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    defaultValue={editingContent.tag || "none"}
                  >
                    <option value="none">No Tag</option>
                    <option value="NEW">NEW</option>
                    <option value="HOT">HOT</option>
                    <option value="TRENDING">TRENDING</option>
                  </select>
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea 
                    id="description" 
                    name="description"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary h-24"
                    defaultValue={editingContent.description}
                    required
                  ></textarea>
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Current Image</label>
                  <div className="relative h-40 mb-4">
                    <img 
                      src={editingContent.imagePath} 
                      alt={editingContent.title} 
                      className="h-full object-cover rounded-md" 
                    />
                  </div>
                  
                  <label className="block text-sm font-medium text-gray-700 mb-1">Upload New Image (Optional)</label>
                  <FileUpload 
                    onFileChange={setUpdatedFile}
                    accept="image/*"
                    maxSize={5 * 1024 * 1024} // 5MB
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="ctaLink" className="block text-sm font-medium text-gray-700 mb-1">CTA Button Link</label>
                  <input 
                    type="url" 
                    id="ctaLink" 
                    name="ctaLink"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    defaultValue={editingContent.ctaLink}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="ctaText" className="block text-sm font-medium text-gray-700 mb-1">CTA Button Text</label>
                  <input 
                    type="text" 
                    id="ctaText" 
                    name="ctaText"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    defaultValue={editingContent.ctaText}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select 
                    id="status" 
                    name="status"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    defaultValue={editingContent.status}
                  >
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                  </select>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setEditFormOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-primary text-white hover:bg-primary/90"
                  disabled={updateMutation.isPending}
                >
                  {updateMutation.isPending ? "Updating..." : "Update Content"}
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Admin;
