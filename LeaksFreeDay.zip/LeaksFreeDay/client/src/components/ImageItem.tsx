import { ContentItem } from "@shared/schema";

interface ImageItemProps {
  item: ContentItem;
}

const ImageItem = ({ item }: ImageItemProps) => {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg">
      <div className="relative h-56 overflow-hidden">
        <img 
          src={item.imagePath} 
          alt={item.title}
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
        {item.tag && (
          <div className="absolute top-2 right-2 bg-primary text-white px-3 py-1 rounded-full text-xs font-semibold">
            {item.tag}
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
        <p className="text-gray-300 text-sm mb-4">{item.description}</p>
        <a 
          href={item.ctaLink}
          target="_blank"
          rel="noopener noreferrer"
          className="block w-full bg-primary text-white text-center py-2 rounded-md hover:bg-primary/90 transition mb-2"
        >
          {item.ctaText}
        </a>
        
        {item.cta2Link && item.cta2Text && (
          <a 
            href={item.cta2Link}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full bg-gray-700 text-white text-center py-2 rounded-md hover:bg-gray-600 transition"
          >
            {item.cta2Text}
          </a>
        )}
      </div>
    </div>
  );
};

export default ImageItem;