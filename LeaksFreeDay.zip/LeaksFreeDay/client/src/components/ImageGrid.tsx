import { useQuery } from "@tanstack/react-query";
import ContentCard from "./ContentCard";
import { ContentItem } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const ImageGrid = () => {
  const { data: contentItems, isLoading, error } = useQuery<ContentItem[]>({
    queryKey: ["/api/content"],
  });
  
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, index) => (
          <div key={index} className="bg-gray-800 rounded-lg overflow-hidden shadow-lg">
            <Skeleton className="w-full h-56 bg-gray-700" />
            <div className="p-4">
              <Skeleton className="h-6 w-3/4 mb-2 bg-gray-700" />
              <Skeleton className="h-4 w-full mb-4 bg-gray-700" />
              <Skeleton className="h-10 w-full bg-gray-700" />
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-red-500">Error loading content. Please try again later.</p>
      </div>
    );
  }
  
  if (!contentItems || contentItems.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-400">No content available.</p>
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {contentItems.map((item) => (
        <ContentCard key={item.id} content={item} />
      ))}
    </div>
  );
};

export default ImageGrid;
