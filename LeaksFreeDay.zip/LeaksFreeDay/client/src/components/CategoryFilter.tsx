import { useState } from "react";
import { Button } from "./ui/button";
import { ContentItem } from "@shared/schema";

interface CategoryFilterProps {
  onCategoryChange: (category: string | null) => void;
}

const CategoryFilter = ({ onCategoryChange }: CategoryFilterProps) => {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  
  const categories = ["Models", "Siterip", "Bigpack"];
  
  const handleCategoryClick = (category: string) => {
    if (activeCategory === category) {
      setActiveCategory(null);
      onCategoryChange(null);
    } else {
      setActiveCategory(category);
      onCategoryChange(category);
    }
  };
  
  return (
    <div className="flex flex-wrap justify-center gap-3 mb-8">
      <div className="flex flex-wrap gap-3 justify-center w-full">
        {categories.map(category => (
          <Button
            key={category}
            onClick={() => handleCategoryClick(category)}
            variant={activeCategory === category ? "default" : "outline"}
            className={
              activeCategory === category
              ? "bg-primary text-white hover:bg-primary/90 border-none"
              : "bg-transparent text-white hover:bg-gray-800 border border-gray-700"
            }
          >
            {category}
          </Button>
        ))}
        
        {activeCategory && (
          <Button
            variant="ghost"
            onClick={() => {
              setActiveCategory(null);
              onCategoryChange(null);
            }}
            className="text-gray-400 hover:text-white hover:bg-transparent"
          >
            Clear Filter
          </Button>
        )}
      </div>
    </div>
  );
};

export default CategoryFilter;