import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";

const Navbar = () => {
  const [, navigate] = useLocation();
  const { isAuthenticated, logout } = useAuth();

  return (
    <nav className="bg-black border-b border-gray-800 shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="flex items-center gap-2">
            <img src="/src/assets/logo.png" alt="LEAKSFREEDAY Logo" className="h-10 w-10" />
            <h1 className="text-2xl font-bold text-primary cursor-pointer">LEAKSFREEDAY</h1>
          </Link>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          <a 
            href="https://t.me/leaksfreedayportal" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-primary text-white hover:bg-primary/90 px-4 py-2 rounded-md flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-telegram" viewBox="0 0 16 16">
              <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/>
            </svg>
            Join our Telegram
          </a>
          
          {isAuthenticated ? (
            <>
              <Link href="/admin" className="text-white hover:text-primary transition">
                Admin
              </Link>
              <Button
                variant="default"
                className="bg-primary text-white hover:bg-primary/90"
                onClick={() => logout()}
              >
                Logout
              </Button>
            </>
          ) : (
            <Link href="/login">
              <Button variant="default" className="bg-primary text-white hover:bg-primary/90">
                Login
              </Button>
            </Link>
          )}
        </div>
        
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-black border-l border-gray-800">
              <div className="flex flex-col gap-4 mt-8">
                <a 
                  href="https://t.me/leaksfreedayportal" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-primary text-white hover:bg-primary/90 px-4 py-2 rounded-md flex items-center gap-2"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-telegram" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/>
                  </svg>
                  Join our Telegram
                </a>
                
                {isAuthenticated ? (
                  <>
                    <Link href="/admin" className="text-white hover:text-primary transition py-2">
                      Admin
                    </Link>
                    <Button
                      variant="default"
                      className="bg-primary text-white hover:bg-primary/90 mt-2"
                      onClick={() => logout()}
                    >
                      Logout
                    </Button>
                  </>
                ) : (
                  <Link href="/login">
                    <Button variant="default" className="bg-primary text-white hover:bg-primary/90 mt-2">
                      Login
                    </Button>
                  </Link>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
