import { useState, useEffect, useRef } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ImageGrid from "@/components/ImageGrid";
import SearchBar from "@/components/SearchBar";
import CategoryFilter from "@/components/CategoryFilter";
import { useQuery } from "@tanstack/react-query";
import { ContentItem } from "@shared/schema";

const Home = () => {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [displayContent, setDisplayContent] = useState<ContentItem[] | null>(null);
  
  // Get all published content
  const { data: allContent = [] } = useQuery<ContentItem[]>({
    queryKey: ["/api/content"],
    retry: false,
  });
  
  // Apply filters whenever allContent, searchQuery, or activeCategory change
  useEffect(() => {
    if (!allContent.length) return;
    
    let filtered = [...allContent];
    
    // Apply search filter if we have a search query
    if (searchQuery) {
      const lowerQuery = searchQuery.toLowerCase();
      filtered = filtered.filter(item => 
        item.title.toLowerCase().includes(lowerQuery) ||
        item.description.toLowerCase().includes(lowerQuery) ||
        (item.tag && item.tag.toLowerCase().includes(lowerQuery))
      );
    }
    
    // Apply category filter if we have an active category
    if (activeCategory) {
      filtered = filtered.filter(item => 
        item.category === activeCategory
      );
    }
    
    if (searchQuery || activeCategory) {
      setDisplayContent(filtered);
    } else {
      setDisplayContent(null); // Use default content display
    }
  }, [allContent, searchQuery, activeCategory]);
  
  // Handle search input
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };
  
  // Handle category selection
  const handleCategoryChange = (category: string | null) => {
    setActiveCategory(category);
  };
  return (
    <div className="min-h-screen flex flex-col bg-black">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative bg-black text-white h-[400px]">
          <div className="hero-image">
            <img 
              src="/src/assets/hero-background.png" 
              alt="LeaksFreeDay Hero" 
              className="object-cover object-center w-full h-full"
            />
          </div>
          <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
            <div className="max-w-3xl mx-auto text-center bg-black/70 p-6 rounded-lg shadow-lg backdrop-blur-sm">
              <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white">WELCOME TO LEAKSFREEDAY</h2>
              <p className="text-lg md:text-xl mb-8 text-white">Since 2020 Find the leaks here!</p>
              <a 
                href="https://t.me/leaksfreedayportal" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-block px-6 py-3 bg-primary text-white font-medium rounded-md hover:bg-primary/90 transition flex items-center gap-2 mx-auto justify-center"
                style={{ maxWidth: "220px" }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-telegram" viewBox="0 0 16 16">
                  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/>
                </svg>
                Join our Telegram
              </a>
            </div>
          </div>
        </section>
        
        {/* Content Preview Grid */}
        <section id="content" className="py-12 md:py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 text-white">Today's Premium Content</h2>
            
            <SearchBar onSearch={handleSearch} />
            <CategoryFilter onCategoryChange={handleCategoryChange} />
            
            {displayContent !== null ? (
              displayContent.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {displayContent.map((item: ContentItem) => (
                    <div key={item.id} className="bg-gray-800 rounded-lg overflow-hidden shadow-lg">
                      <div className="relative h-56 overflow-hidden">
                        <img 
                          src={item.imagePath} 
                          alt={item.title}
                          className="w-full h-full object-cover transition-transform hover:scale-105"
                        />
                        {item.tag && (
                          <div className="absolute top-2 right-2 bg-primary text-white px-3 py-1 rounded-full text-xs font-semibold">
                            {item.tag}
                          </div>
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                        <p className="text-gray-300 text-sm mb-4">{item.description}</p>
                        <a 
                          href={item.ctaLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block w-full bg-primary text-white text-center py-2 rounded-md hover:bg-primary/90 transition mb-2"
                        >
                          {item.ctaText}
                        </a>
                        
                        {item.cta2Link && item.cta2Text && (
                          <a 
                            href={item.cta2Link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block w-full bg-gray-700 text-white text-center py-2 rounded-md hover:bg-gray-600 transition"
                          >
                            {item.cta2Text}
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <p className="text-white text-lg">No results found for your search.</p>
                  <p className="text-gray-400">Try a different search term.</p>
                </div>
              )
            ) : (
              <ImageGrid />
            )}
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;
