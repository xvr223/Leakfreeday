import { 
  users, 
  contentItems, 
  type User, 
  type InsertUser, 
  type ContentItem, 
  type InsertContentItem, 
  type UpdateContentItem 
} from "@shared/schema";
import fs from "fs";
import path from "path";
import { createHash } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Content operations
  getAllContent(): Promise<ContentItem[]>;
  getPublishedContent(): Promise<ContentItem[]>;
  getContentById(id: number): Promise<ContentItem | undefined>;
  createContent(content: InsertContentItem): Promise<ContentItem>;
  updateContent(id: number, content: UpdateContentItem): Promise<ContentItem | undefined>;
  deleteContent(id: number): Promise<boolean>;
  
  // File operations
  saveFile(file: Express.Multer.File): Promise<string>;
  getFilePath(filename: string): string;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private content: Map<number, ContentItem>;
  private userId: number;
  private contentId: number;
  private filesDir: string;

  constructor() {
    this.users = new Map();
    this.content = new Map();
    this.userId = 1;
    this.contentId = 1;
    this.filesDir = path.join(process.cwd(), "uploads");
    
    // Create uploads directory if it doesn't exist
    if (!fs.existsSync(this.filesDir)) {
      fs.mkdirSync(this.filesDir, { recursive: true });
    }
    
    // Add default admin user
    this.createUser({
      username: "admin",
      password: this.hashPassword("admin123"),
    });
    
    // Add some initial content for testing
    this.initializeContent();
  }

  private hashPassword(password: string): string {
    return createHash("sha256").update(password).digest("hex");
  }
  
  private initializeContent() {
    // This is just placeholder data - in a real app we wouldn't do this
    const initialContent: InsertContentItem[] = [
      {
        title: "Premium Collection #1",
        description: "Exclusive content from our premium selection",
        imagePath: "/uploads/placeholder1.jpg",
        tag: "NEW",
        ctaLink: "https://example.com/premium1",
        ctaText: "Unlock Content",
        status: "published"
      },
      {
        title: "Premium Collection #2",
        description: "Special exclusive content updated today",
        imagePath: "/uploads/placeholder2.jpg",
        tag: "HOT",
        ctaLink: "https://example.com/premium2",
        ctaText: "Unlock Content",
        status: "published"
      }
    ];
    
    // Create placeholder content
    initialContent.forEach(item => {
      const id = this.contentId++;
      const now = new Date();
      this.content.set(id, { ...item, id, createdAt: now });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Content operations
  async getAllContent(): Promise<ContentItem[]> {
    return Array.from(this.content.values()).sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  
  async getPublishedContent(): Promise<ContentItem[]> {
    return Array.from(this.content.values())
      .filter(item => item.status === "published")
      .sort((a, b) => {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }

  async getContentById(id: number): Promise<ContentItem | undefined> {
    return this.content.get(id);
  }

  async createContent(content: InsertContentItem): Promise<ContentItem> {
    const id = this.contentId++;
    const now = new Date();
    const newContent: ContentItem = { ...content, id, createdAt: now };
    this.content.set(id, newContent);
    return newContent;
  }

  async updateContent(id: number, updateData: UpdateContentItem): Promise<ContentItem | undefined> {
    const content = this.content.get(id);
    if (!content) return undefined;

    const updatedContent: ContentItem = { ...content, ...updateData };
    this.content.set(id, updatedContent);
    return updatedContent;
  }

  async deleteContent(id: number): Promise<boolean> {
    return this.content.delete(id);
  }

  // File operations
  async saveFile(file: Express.Multer.File): Promise<string> {
    const fileExt = path.extname(file.originalname);
    const fileName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${fileExt}`;
    const filePath = path.join(this.filesDir, fileName);
    
    // Create a write stream
    const writeStream = fs.createWriteStream(filePath);
    
    // Write the file
    return new Promise((resolve, reject) => {
      writeStream.write(file.buffer);
      writeStream.end();
      writeStream.on("finish", () => resolve(`/uploads/${fileName}`));
      writeStream.on("error", reject);
    });
  }
  
  getFilePath(filename: string): string {
    return path.join(this.filesDir, path.basename(filename));
  }
}

export const storage = new MemStorage();
