import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { ZodError } from "zod";
import { LoginCredentials, loginSchema, insertContentSchema, updateContentSchema } from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";
import { createHash } from "crypto";

// Configure multer for in-memory storage
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// Create session store
const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session middleware
  app.use(session({
    secret: "leaksfreeday-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 86400000 }, // 24 hours
    store: new SessionStore({ checkPeriod: 86400000 })
  }));

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.session.authenticated) {
      return next();
    }
    return res.status(401).json({ message: "Unauthorized" });
  };

  // Helper function to hash passwords
  const hashPassword = (password: string): string => {
    return createHash("sha256").update(password).digest("hex");
  };

  // Serve uploaded files
  app.use("/uploads", (req, res, next) => {
    const filePath = path.join(process.cwd(), req.url);
    if (fs.existsSync(filePath)) {
      return res.sendFile(filePath);
    }
    next();
  });

  // ===== Authentication Routes =====
  
  // Login
  app.post("/api/login", async (req, res) => {
    try {
      const credentials: LoginCredentials = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(credentials.username);
      
      if (!user || user.password !== hashPassword(credentials.password)) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      req.session.authenticated = true;
      req.session.userId = user.id;
      
      return res.status(200).json({ message: "Login successful" });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.format() });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Logout
  app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logout successful" });
    });
  });
  
  // Check authentication status
  app.get("/api/auth/status", (req, res) => {
    return res.status(200).json({
      authenticated: !!req.session.authenticated
    });
  });

  // ===== Content Routes =====
  
  // Get all content (public)
  app.get("/api/content", async (req, res) => {
    try {
      const content = await storage.getPublishedContent();
      return res.status(200).json(content);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch content" });
    }
  });
  
  // Get all content (admin)
  app.get("/api/admin/content", isAuthenticated, async (req, res) => {
    try {
      const content = await storage.getAllContent();
      return res.status(200).json(content);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch content" });
    }
  });
  
  // Get content by ID
  app.get("/api/content/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const content = await storage.getContentById(id);
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      
      return res.status(200).json(content);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch content" });
    }
  });
  
  // Create content
  app.post("/api/content", isAuthenticated, upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Image file is required" });
      }
      
      // Parse and validate content data
      const contentData = JSON.parse(req.body.data);
      const validatedData = insertContentSchema.parse(contentData);
      
      // Save the uploaded file
      const imagePath = await storage.saveFile(req.file);
      
      // Create content with file path
      const newContent = await storage.createContent({
        ...validatedData,
        imagePath
      });
      
      return res.status(201).json(newContent);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.format() });
      }
      console.error(error);
      return res.status(500).json({ message: "Failed to create content" });
    }
  });
  
  // Update content
  app.patch("/api/content/:id", isAuthenticated, upload.single("image"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      // Check if content exists
      const existingContent = await storage.getContentById(id);
      if (!existingContent) {
        return res.status(404).json({ message: "Content not found" });
      }
      
      // Parse and validate content data
      const contentData = JSON.parse(req.body.data);
      const validatedData = updateContentSchema.parse(contentData);
      
      // If there's a new image, save it
      let updateData = validatedData;
      if (req.file) {
        const imagePath = await storage.saveFile(req.file);
        updateData = { ...validatedData, imagePath };
      }
      
      // Update content
      const updatedContent = await storage.updateContent(id, updateData);
      
      return res.status(200).json(updatedContent);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.format() });
      }
      return res.status(500).json({ message: "Failed to update content" });
    }
  });
  
  // Delete content
  app.delete("/api/content/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      // Check if content exists
      const content = await storage.getContentById(id);
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      
      // Delete content
      const success = await storage.deleteContent(id);
      
      if (success) {
        return res.status(200).json({ message: "Content deleted successfully" });
      } else {
        return res.status(500).json({ message: "Failed to delete content" });
      }
    } catch (error) {
      return res.status(500).json({ message: "Failed to delete content" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
