import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ContentItem } from "@shared/schema";

interface ContentCardProps {
  content: ContentItem;
}

const ContentCard = ({ content }: ContentCardProps) => {
  const { title, description, imagePath, tag, ctaLink, ctaText, category } = content;
  
  const getTagClass = (tag: string | null) => {
    if (!tag) return "";
    
    switch (tag.toUpperCase()) {
      case "NEW":
        return "bg-primary text-white";
      case "HOT":
        return "bg-primary text-white";
      case "TRENDING":
        return "bg-accent text-white";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  const getCategoryClass = (category: string | null) => {
    if (!category) return "bg-gray-600 text-white";
    
    switch (category) {
      case "Models":
        return "bg-pink-600 text-white";
      case "Siterip":
        return "bg-purple-600 text-white";
      case "Bigpack":
        return "bg-blue-600 text-white";
      default:
        return "bg-gray-600 text-white";
    }
  };
  
  return (
    <Card className="overflow-hidden bg-gray-800 shadow-lg hover:shadow-xl transition border-0">
      <div className="relative h-56">
        <img 
          src={imagePath} 
          alt={title} 
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
        <div className="absolute top-2 left-2">
          <Badge className={`${getCategoryClass(category)} px-3 py-1 text-xs font-semibold rounded-full`}>
            {category || "Models"}
          </Badge>
        </div>
        {tag && (
          <div className="absolute top-2 right-2">
            <Badge className={`${getTagClass(tag)} px-3 py-1 text-xs font-semibold rounded-full`}>
              {tag}
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-2 text-white">{title}</h3>
        <p className="text-gray-300 text-sm mb-4">{description}</p>
        <a 
          href={ctaLink} 
          target="_blank" 
          rel="noopener noreferrer"
          className="w-full block text-center px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition"
        >
          {ctaText}
        </a>
      </CardContent>
    </Card>
  );
};

export default ContentCard;
